"""
Utils function for VMRay
"""
# pylint: disable=logging-fstring-interpolation
import logging
import re
import time
import uuid
from datetime import datetime, timezone
from os import environ
from typing import Dict, Union

import requests

FETCHED_SAMPLE_IOCS = {}
FETCHED_SAMPLE = {}

IOC_LIST = ["domains", "ips", "urls", "files"]
RETRY_STATUS_CODE = [500, 501, 502, 503, 504, 429]
RATING = {"malicious": "5.0", "suspicious": "3.0"}
CONFIDENCE = {"malicious": "100", "suspicious": "75"}

USER_AGENT = "VMRayThreatIntelligenceSentinel:1.0.0"

INDICATOR_LIST = []
IPV4REGEX = r"^(?P<ipv4>(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?))[:]?(?P<port>\d+)?$"
IPV6REGEX = r"^(?:(?:[0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,7}:|(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:(?:(:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))$"  # noqa: E501

vmrayBaseURL = environ.get("VmrayBaseURL")
vmray_api_key = environ.get("VmrayAPIKey")


def is_json(response):
    """Checks if response is jsonable

    Args:
        response (requests.Response):

    Returns:
        bool: true if object is jsonable
    """
    try:
        response.json()
    except ValueError:
        return False
    return True


def do_request(endpoint, params, max_retries=3, delay=1):
    """
    Call VMRay API

    Parameters
    ----------
    endpoint : str
        The specific API endpoint to send the request to (e.g., "analyze", "reports").
    params : dict
        The query parameters to include in the request.
    max_retries : int, optional
        The maximum number of retry attempts for a request (default is 3).
    delay : int, optional
        The amount of time in seconds to wait between retry attempts (default is 1).

    Returns
    -------
    requests.Response
        The response received from the VMRay API if the request is successful.

    Raises
    ------
    requests.HTTPError
        If an HTTP error is encountered that is not eligible for a retry.
    ValueError
        If the response is not in JSON format.
    Exception
        If the request fails after all retry attempts or an unexpected error occurs.
    """
    headers = {"Authorization": f"api_key {vmray_api_key}", "User-Agent": USER_AGENT}

    retry_429 = 0

    while retry_429 < max_retries:
        try:
            response = requests.get(
                url=f"{vmrayBaseURL}/rest/{endpoint}", headers=headers, params=params
            )

            if not is_json(response):
                raise ValueError("Response is not in JSON format.")
            response.raise_for_status()
            return response

        except requests.HTTPError as herr:
            if response.status_code in RETRY_STATUS_CODE:
                logging.warning(
                    f"HTTP {response.status_code}:"
                    f" {response.json().get('error_msg', 'No error_msg')}"
                )
                logging.info(
                    f"Retrying ({retry_429 + 1}/{max_retries}) after {delay}s..."
                )
                time.sleep(delay)
                retry_429 += 1
                continue
            logging.error(
                f"HTTP error: {herr} - {response.json().get('error_msg', 'No error_msg')}"
            )
            raise

        except ValueError as verr:
            logging.error(f"ValueError: {verr}")
            logging.error(f"Response content: {response.text}")
            raise

        except Exception as err:
            logging.error(f"Unexpected error: {err}")
            raise

    raise Exception("Failed to complete VMRay request after multiple retries.")


def get_submission(verdict, from_time, to_time):
    """
    Fetch submissions based on verdict and time range.

    Args:
        verdict (list of str): A list of submission verdicts to filter results,
            such as "accepted," "wrong answer," etc.
        from_time (str): Starting range for submission time in ISO 8601 format.
        to_time (str): Ending range for submission time in ISO 8601 format.

    Returns:
        list: A list of submission data, consisting of dictionaries, as retrieved
            from the API responses.
    """
    submission_response = []
    try:
        logging.info(f"User-Agent: {USER_AGENT}")
        logging.info(f"Fetching submission from {from_time}~{to_time}")
        for ver in verdict:
            params = {
                "submission_finish_time": f"{from_time}~{to_time}",
                "submission_verdict": ver.strip().lower(),
            }
            response = do_request("submission", params).json()
            submission_response.extend(response.get("data", []))
            while response.get("continuation_id"):
                response = do_request(
                    f"continuation/{response.get('continuation_id')}", {}
                ).json()
                submission_response.extend(response.get("data", []))
        return submission_response
    except Exception as err:
        logging.error(f"Error {err}")
        return submission_response


def get_sample(sample_id):
    """
    Fetches and caches the details of a specific sample from an VMRay API.

    Arguments:
        sample_id (int): The identifier of the sample to fetch.

    Returns:
        dict: Details of the specified sample if successful, or an empty dictionary upon failure.
    """
    try:
        if not sample_id in FETCHED_SAMPLE:
            sample_response = do_request(f"sample/{sample_id}", {}).json().get("data", {})
            FETCHED_SAMPLE[sample_id] = sample_response
            return sample_response
        return FETCHED_SAMPLE.get(sample_id)
    except Exception as err:
        logging.error(f"Error {err}")
        return {}


def get_sample_ioc(sample_id):
    """
    Fetch and cache indicators of compromise (IOCs) for a given sample ID.

    Args:
        sample_id (str): The unique identifier of the sample for which to fetch
            indicators of compromise.

    Returns:
        dict: A dictionary containing the indicators of compromise for the specified
        sample ID. If an error occurred or the data could not be fetched, an empty
        dictionary is returned.
    """
    try:
        if not sample_id in FETCHED_SAMPLE_IOCS:
            ioc_response = (
                do_request(f"sample/{sample_id}/iocs", {})
                .json()
                .get("data", {})
                .get("iocs", {})
            )
            FETCHED_SAMPLE_IOCS[sample_id] = ioc_response
            return ioc_response
        return FETCHED_SAMPLE_IOCS.get(sample_id)
    except Exception as err:
        logging.error(f"Error {err}")
        return {}


def add_domain_indicator(domains, sample_id, submission_id, verdicts):
    """
    Adds domain indicators to the global indicator list if the verdict of the
    domains matches any of the provided verdicts.

    Parameters:
        domains (list): A list of domain dictionaries, each containing information
            about a domain (e.g., 'domain', 'verdict').
        sample_id: An identifier for the associated sample related to the domain.
        submission_id: An identifier for the associated submission related to the
            domain.
        verdicts (list): A list of valid verdicts used to filter domains. Each
            verdict is compared against the 'verdict' field of the domains in a
            case-insensitive manner.

    Raises:
        Exception: Any exceptions that occur during processing are caught,
            logged with an error message, and handled silently.

    Returns:
        None
    """
    try:
        for domain in domains:
            verdict = domain.get("verdict")
            if verdict.capitalize() in verdicts:
                domain_pattern = f"[domain-name:value = '{domain.get('domain')}']"
                domain_name = domain.get("domain", "")
                unique_id = gen_unique_id("domain", domain_name)
                data = get_static_data(
                    unique_id,
                    domain,
                    domain_pattern,
                    sample_id,
                    submission_id,
                    domain_name,
                    CONFIDENCE.get(verdict.lower(), 0),
                )
                INDICATOR_LIST.append(data)

        return
    except Exception as err:
        logging.error(f"Error {err}")
        return


def add_file_indicators(files, sample_id, submission_id, verdicts):
    """
    Adds file indicators based on given files, their verdicts, and associated identifiers.
    Processes each file to extract hash values, generates unique IDs, constructs specific
    patterns, and retrieves or constructs data based on these values, appending them to
    a global indicator list. Handles errors that occur during processing and logs them.

    Arguments:
    - files: list
        List of file data items to process, each containing metadata such as hashes,
        verdicts, and filenames.
    - sample_id: str
        Unique identifier for the sample to associate with generated indicators.
    - submission_id: str
        Identifier representing the submission instance related to the files.
    - verdicts: list
        Accepted verdicts for processing files, with verdicts being matched
        case-insensitively.

    Exceptions:
    - Exception
        Catches any processing errors, logs error details, and ensures any unhandled
        exceptions are gracefully handled.
    """
    try:
        for file in files:
            verdict = file.get("verdict")
            if verdict.capitalize() in verdicts:
                file_summary_list = file.get("hashes", [])[0]
                md5 = file_summary_list.get("md5_hash")
                sha1 = file_summary_list.get("sha1_hash")
                sha256 = file_summary_list.get("sha256_hash")
                md5_pattern = f"[file:hashes.'MD5' = '{md5}']"
                sha1_pattern = f"[file:hashes.'SHA-1' = '{sha1}']"
                sha256_pattern = f"[file:hashes.'SHA-256' = '{sha256}']"
                filename = file.get("filename", "")
                unique_md5_id = gen_unique_id("file", md5)
                unique_sha256_id = gen_unique_id("file", sha256)
                unique_sha1_id = gen_unique_id("file", sha1)
                data_md5 = get_static_data(
                    unique_md5_id,
                    file,
                    md5_pattern,
                    sample_id,
                    submission_id,
                    filename or md5,
                    CONFIDENCE.get(verdict.lower(), 0),
                )
                data_sha1 = get_static_data(
                    unique_sha1_id,
                    file,
                    sha1_pattern,
                    sample_id,
                    submission_id,
                    filename or sha1,
                    CONFIDENCE.get(verdict.lower(), 0),
                )
                data_sha256 = get_static_data(
                    unique_sha256_id,
                    file,
                    sha256_pattern,
                    sample_id,
                    submission_id,
                    filename or sha256,
                    CONFIDENCE.get(verdict.lower(), 0),
                )
                INDICATOR_LIST.append(data_md5)
                INDICATOR_LIST.append(data_sha1)
                INDICATOR_LIST.append(data_sha256)
        return
    except Exception as err:
        logging.error(f"Error {err}")
        return


def get_utc_time():
    """
    Gets the current time in UTC formatted as an ISO 8601 timestamp with
    milliseconds and 'Z' denoting the UTC timezone.

    This function retrieves the current UTC time, formats it to include
    milliseconds, and appends the 'Z' character to indicate that the time
    is in UTC.

    Returns:
        str: The current UTC time formatted as an ISO 8601 timestamp
        (e.g., 'YYYY-MM-DDTHH:MM:SS.mmmZ').
    """
    current_time = datetime.now(timezone.utc)

    # Format the current time with milliseconds and UTC timezone
    formatted_time = (
        current_time.strftime("%Y-%m-%dT%H:%M:%S.")
        + f"{current_time.microsecond // 1000:03d}Z"
    )
    return formatted_time


def check_ip(ip):
    """
    Checks the provided IP address and determines its type based on matching
    regular expressions for IPv4 and IPv6. Returns a string indicating the
    type of IP address or None if the IP format is invalid.

    Args:
        ip (str): The IP address to be checked.

    Returns:
        str or None: Returns 'ipv4-addr' for IPv4 addresses, 'ipv6-addr' for
        IPv6 addresses, or None if the input does not match any valid IP format.
    """
    if re.match(IPV4REGEX, ip):
        return "ipv4-addr"
    if re.match(IPV6REGEX, ip):
        return "ipv6-addr"

    return None


def add_ip_indicator(ips, sample_id, submission_id, verdicts):
    """
    Adds IP indicators to a global list based on given criteria, such as verdicts.

    This function iterates over a list of IPs and processes each IP to evaluate if it
    matches specific verdicts. If a match is found, the function generates associated
    static data for the IP, such as IP type and a unique identifier, and appends it
    to the global indicator list.

    Parameters:
    ips : list
        A list of dictionaries, each containing information about an IP such as
        its address and verdict.
    sample_id : str
        A unique identifier assigned to the sample under examination.
    submission_id : str
        A unique identifier assigned to the submission related to the IP indicators.
    verdicts : list
        A list of strings specifying the verdicts of interest for filtering IPs.
    """
    try:
        for ip in ips:
            verdict = ip.get("verdict")
            if verdict.capitalize() in verdicts:
                ip_add = ip.get("ip_address", "")
                ip_type = check_ip(ip_add)
                if ip_type:
                    ip_pattern = f"[{ip_type}:value = '{ip_add}']"
                    unique_id = gen_unique_id("ip", ip_add)
                    data = get_static_data(
                        unique_id,
                        ip,
                        ip_pattern,
                        sample_id,
                        submission_id,
                        ip_add,
                        CONFIDENCE.get(verdict.lower(), 0),
                    )
                    INDICATOR_LIST.append(data)
        return
    except Exception as err:
        logging.error(f"Error {err}")
        return


def add_url_indicator(urls, sample_id, submission_id, verdicts):
    """
    Adds URL indicators to the global indicator list (INDICATOR_LIST) if the verdict of the URL
    matches with the provided verdicts list. It generates unique identifiers, processes URLs, and
    adds relevant static data for indicators.

    Parameters:
    urls: list
        List of dictionaries, where each dictionary represents a URL and contains details such as
        the URL string and its associated verdict.
    sample_id: Any
        Identifier for the sample associated with the URLs.
    submission_id: Any
        Identifier for the submission associated with the sample and URLs.
    verdicts: list
        List of verdicts considered valid for inclusion in the indicator list.
    """
    try:
        for url in urls:
            verdict = url.get("verdict")
            if verdict.capitalize() in verdicts:
                url_name = url.get("url", "")
                url_pattern = f"[url:value = '{url_name}']"
                unique_id = gen_unique_id("url", url_name)
                data = get_static_data(
                    unique_id,
                    url,
                    url_pattern,
                    sample_id,
                    submission_id,
                    url_name,
                    CONFIDENCE.get(verdict.lower(), 0),
                )
                INDICATOR_LIST.append(data)
        return
    except Exception as err:
        logging.error(f"Error {err}")


def gen_unique_id(
    indicator_type: str, indicator_value: str, threat_source: str = "VMRay"
):
    """
    Generate a unique identifier for a threat indicator.

    This function creates a unique identifier by combining an indicator type, an indicator_value,
    and a threat source. It ensures that the identifier is consistent and uniquely represents
    the combination of these inputs.

    Parameters:
        indicator_type: str
            'file', 'email', 'domain', 'url', etc.
        indicator_value: str
           a hash, IP address, domain name, or STIX pattern.
        threat_source: str, optional
            namespace to isolate ID generation per source/system".

    Returns:
        str
            A generated unique identifier string that combines the input information.
    """
    custom_namespace = uuid.uuid5(uuid.NAMESPACE_DNS, threat_source)
    name_string = f"{indicator_type}:{indicator_value}"
    indicator_uuid = uuid.uuid5(custom_namespace, name_string)
    return f"indicator--{indicator_uuid}"


def get_static_data(
    unique_uuid, indicator, pattern, sample_id, submission_id, name, confidence
) -> Dict[str, Union[str, int, list]]:
    """
    Generate a static data dictionary for an indicator based on provided parameters.

    This function constructs a dictionary containing detailed information about
    an indicator, formatted according to a specific schema. It incorporates multiple
    fields including metadata, references, labels, and pattern-related data. The function
    also sanitizes the input data where necessary.

    Parameters:
        unique_uuid (Str): A unique identifier for the indicator, used as the primary key.
        indicator (dict): A dictionary holding information about the indicator,
            including fields such as `analysis_ids`, `categories`, `classifications`,
            `threat_names`, and `ioc_type`.
        pattern (str): A string representing the indicator pattern, used for
            defining the indicator's matching conditions.
        sample_id (str): The unique identifier for the sample associated with the indicator.
        submission_id (str): The unique identifier for the submission associated
            with the indicator.
        name (str): A descriptive name for the indicator.
        confidence (int): An integer value representing the computation of the confidence
            level associated with the indicator.

    Returns:
        dict: A dictionary containing the structured data for the indicator, including
            fields for type, specification version, identifier, timestamps, and external
            references.
    """
    analysis = ", ".join(map(str, indicator.get("analysis_ids", [])))
    categories = ", ".join(indicator.get("categories", []))
    classifications = ", ".join(indicator.get("classifications", []))
    threat_names = indicator.get("threat_names", [])
    t_type = []
    for threat in threat_names:
        if re.match(r"^[a-zA-Z0-9\s]+$", threat):
            t_type.append(threat)
    tags = [
        f"sample_id: {sample_id}",
        f"submission_id: {submission_id}",
        f"threat_names: {', '.join(t_type)}",
        f"Classifications: {classifications}",
    ]

    data = {
        "type": "indicator",
        "spec_version": "2.1",
        "id": unique_uuid,
        "created": get_utc_time(),
        "modified": get_utc_time(),
        "revoked": False,
        "labels": tags,
        "confidence": confidence,
        "external_references": [
            {
                "source_name": "VMRay Threat Intelligence",
                "description": f"Sample ID {sample_id}\nSubmission ID {submission_id}",
                "url": f"{vmrayBaseURL}/sample/{sample_id}#summary",
            }
        ],
        "name": name,
        "description": f"Sample URL: {vmrayBaseURL}/sample/{sample_id}#summary,"
                       f"\nAnalysis IDs: {analysis},\nCategories: {categories}",
        "indicator_types": [indicator.get("ioc_type", "")],
        "pattern": pattern,
        "pattern_type": "stix",
        "pattern_version": "2.1",
        "valid_from": get_utc_time(),
    }
    return data


IOC_MAPPING_FUNCTION = {
    "domains": add_domain_indicator,
    "ips": add_ip_indicator,
    "urls": add_url_indicator,
    "files": add_file_indicators,
}


def indicator_list():
    """
    Returns the list of indicators for use in analytics or processing tasks.

    Returns:
        list: The predefined list of indicators available for operations.
    """
    return INDICATOR_LIST

