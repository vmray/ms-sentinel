"""
VMRay Threat Intelligence
"""

import re
import json
import time
import requests
import traceback
import concurrent.futures
from os import environ
from datetime import datetime, timedelta
import logging
import azure.functions as func
from .state_manager import StateManager
from .utils import *

workspaceID = environ.get("AzureWorkspacseID")
clientID = environ.get("AzureClientID")
clientSecret = environ.get("AzureClientSecret")
tenant_id = environ.get("AzureTenantID")
vmraySampleVerdict = environ.get("VmraySampleVerdict")
vmrayInitialFetchDate = environ.get("VmrayInitialFetchDate")
state = StateManager(environ.get("AzureWebJobsStorage"))

apiVersion = "2024-02-01-preview"
RETRY_STATUS_CODE = [500, 501, 502, 503, 504, 429]


TIMEOUT = 60.0
# There's a limit of 100 tiIndindicator_listicators per request.
MAX_TI_INDICATORS_PER_REQUEST = 100
ENDPOINT = f"https://api.ti.sentinel.azure.com/workspaces/{workspaceID}/threat-intelligence-stix-objects:upload?api-version={apiVersion}"
TOKEN_ENDPOINT = f"https://login.microsoftonline.com/{tenant_id}/oauth2/token"
VMRAY_BASE_URL = environ.get("vmrayBaseURL")
RESOURCE = "https://management.azure.com"

STIX_PARSER = re.compile(
    r"([\w-]+?):(\w.+?) (?:[!><]?=|IN|MATCHES|LIKE) '(.*?)' *[" r"OR|AND|FOLLOWEDBY]?"
)
IOC_MAPPING = {
    "file:hashes.'SHA-1'": "SHA1",
    "file:hashes.MD5": "MD5",
    "file:hashes.'SHA-256'": "SHA256",
    "file:hashes.'SHA-512'": "SHA512",
    "ipv4-addr": "IP",
    "file:name": "File_Extension",
    "file:size": "File_Size",
    "url": "URL",
    "email-addr": "EMAIL",
    "domain-name": "DOMAIN",
    "ipv6-addr": "IP",
    "mac-addr": "MAC",
    "directory": "DIR",
    "mutex": "MUTEX",
    "windows-registry-key": "WINDOWS_REGISTRY_KEY",
}

HEADERS = {
    "Content-Type": "application/x-www-form-urlencoded",
    "accept": "application/json",
}
AZURE_LOGIN_PAYLOAD = {
    "grant_type": "client_credentials",
    "client_id": clientID,
    "client_secret": clientSecret,
    "resource": RESOURCE,
}
USER_AGENT = "VMRayThreatIntelligenceSentinel:1.0.0"


def get_last_saved_timestamp(date_format="%Y-%m-%dT%H:%M:%S"):
    """
    This function retrieves the last saved timestamp from the state. If no
    timestamp is found, it returns 0.

    Parameters:
    date_format (str): The format in which the date and time are represented.
    Default is '%Y-%m-%d %H:%M:%S' which
    represents YYYY-MM-DD HH:MM:SS format.

    Returns:
    int: The timestamp of the last successful run of this function as a Unix
    timestamp. If the function is being run for
    the first time, it returns 0.
    """
    last_run_date_time = state.get()
    logging.debug("last saved time stamp is %s", last_run_date_time)

    return last_run_date_time if last_run_date_time else None


def save_checkpoint(timestamp: str, date_format: str = "%Y-%m-%dT%H:%M:%S") -> None:
    """
    This function saves the current UTC timestamp to the state.

    Parameters:
    date_format (str): The format in which the date and time are represented.
    Default is '%Y-%m-%dT%H:%M:%S'
                       which represents the format as YYYY-MM-DD HH:MM:SS.

    Returns:
    None
    """
    state.post(timestamp)


# def authenticate():
#         """
#         Authenticate using Azure Active Directory application properties, and retrieves the access token
#         :raise: Exception when credentials/application properties are not properly configured
#         :return: void
#         """
#         retry_count = 0
#         # defining request body with application properties and secret
#         # posting defined request data to retrieve access token
#         while retry_count <= 3:
#             try:
#                 response = requests.post(url=TOKEN_ENDPOINT, data=AZURE_LOGIN_PAYLOAD)
#                 response.raise_for_status()
#                 data = json.loads(response.content)
#                 access_token = data["access_token"]
#                 headers = {"Authorization": "Bearer %s" % access_token, "User-Agent": USER_AGENT,
#                                 "Content-Type": "application/json"}
#                 return headers
#             except requests.HTTPError as herr:
#                 logging.error(f"Error in microsoft api request: {herr}")
#                 raise Exception(herr)
#             except requests.ConnectionError as cerr:
#                 
#             except Exception as err:
#                 logging.error(err)
#                 raise Exception(err)


def create_indicator(indicator_data):
    """Attempt
    To create indicator into Microsoft Sentinel.
    """
    retry_count_429 = 0
    retry_connection = 0
    indicator = {
        "sourcesystem": "VMRayThreatIntelligence",
        "stixobjects": indicator_data
    }
    while retry_count_429 <= 3:
        try:
            # Make the request with the provided method, URL, headers, and data
            response = requests.post(url=TOKEN_ENDPOINT, data=AZURE_LOGIN_PAYLOAD)
            response.raise_for_status()
            data = json.loads(response.content)
            access_token = data["access_token"]
            headers = {"Authorization": "Bearer %s" % access_token, "User-Agent": USER_AGENT,
                       "Content-Type": "application/json"}
            response = requests.post(ENDPOINT, headers=headers, data=json.dumps(indicator))
            response.raise_for_status()
            return response
        except requests.HTTPError as herr:
            # Handle network issues, timeouts, or server errors
            if response.status_code in RETRY_STATUS_CODE:
                logging.warning(f"Attempt {retry_count_429 + 1}: Server error or too many requests. Retrying...")
                time.sleep(TIMEOUT)
                retry_count_429 += 1
                continue
            else:
                logging.error(f"Error In Sentinel API calling: {herr}")
                raise Exception(herr)
        except requests.ConnectionError as cerr:
            if retry_connection <= 3:
                logging.warning(f"Attempt {retry_connection + 1}: Request Connection error or too many requests. Retrying...")
                time.sleep(TIMEOUT) 
                retry_connection += 1
                continue
            raise Exception(cerr)
        except requests.exceptions.RequestException as rerr:
            if retry_connection <= 3:
                logging.warning(f"Attempt {retry_connection + 1}: Request Connection error or too many requests. Retrying...")
                time.sleep(TIMEOUT)
                retry_connection += 1
                continue
            raise Exception(rerr)
        except Exception as err:
            raise Exception(err)



def main(mytimer: func.TimerRequest) -> None:
    """
    Main function to handle VMRay API requests.

    This function initializes the VMRay manager, requests and refreshes
    access tokens, handles VMRay API calls,
    and handles pagination to ensure all pages of data are retrieved. It uses
    a timer trigger to run at specified
    intervals.

    :param mytimer: func.TimerRequest, timer for triggering the function at
    specified intervals.

    Note:
    - This function will log an error message and exit if an access token
    cannot be retrieved or refreshed.
    - If no more indicators are left to ingest, the function will log an
    informational message and stop iterating over
    the pages.
    - The function will save a timestamp after each run.
    """
    try:
        if mytimer.past_due:
            logging.info("The timer is past due!")
            return

        initial_date_time = get_last_saved_timestamp() or (datetime.now() - timedelta(days=int(vmrayInitialFetchDate))).strftime("%Y-%m-%dT00:00:00")
        logging.info(f"last_run {get_last_saved_timestamp()}")
        sample_verdict = vmraySampleVerdict
        sample_verdict = sample_verdict.split(" & ")
        logging.info(f"verdict {sample_verdict}")
        current_date = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
        submissions_list = get_submission(sample_verdict, initial_date_time, current_date)
        for sub in submissions_list:
            if sub.get('submission_finished'):
                iocs = get_sample_ioc(sub.get("submission_sample_id"))
                for key, value in iocs.items():
                    if key in IOC_LIST:
                        IOC_MAPPING_FUNCTION[key](value, sub.get("submission_sample_id"), sub.get("submission_id"), sample_verdict)
        indicators = indicator_list()
        logging.info(f"length of indicator {len(indicators)}")
        for i in range(0, len(indicators), MAX_TI_INDICATORS_PER_REQUEST):
            create_indicator(indicators[i:i + MAX_TI_INDICATORS_PER_REQUEST])
        save_checkpoint(current_date)
    except Exception as ex:
        error_detatl = traceback.format_exc()
        logging.error(f"something went wrong. Error: {ex}. Traceback {error_detatl}")




